var post_db = require('../models/postDatabase.js');
/////////////////////////////////////////
/////////POST FUNCTIONS//////////////
/////////////////////////////////////////

//Function to get wall (input is username and will display the user's wall) 
var getWall = function(req, res) {
	//get username and password from frontend
	var username = req.session.secret;
	
	//Check the table for the username using post_db function 
	post_db.get_wall(username, function(err, data) {
		//If err or lookup error send error back to main
		if(err || username == undefined) {
			//redirect back to main with an error
			var errorMessage = "Sorry, looks like we ran into an error";
			res.render('mainpage.ejs', {'error': errorMessage});
		} else {
			// sorts the data
			var dataSorted = data.sort(function(a, b) {
				return b.inxid.N - a.inxid.N;
			});
			//console.log(dataSorted);
			console.log(username);
			res.render('wall.ejs', {'results': dataSorted, 'user': username});
		}
	});
};

//TODO Need to implement to addPost to Post table and User List
var addPost = function(req, res) {
	var username = req.session.secret;
	var content = req.body.content;
	
	//add content to post table and user list
	post_db.add_post(username, content, function(err) {
		//if err in adding or username is undefined send error
		if(err || username == undefined) {
			var errorMessage = "Sorry, looks like we ran into an error adding your post.";
			console.log("error in addPost: " + err);
			//not sure where to redirect too....
			res.render('mainpage.ejs', {'error': errorMessage});
		} else {
			res.redirect('/wall');
		}
	});
	
};

//TODO Need to implement to addPost to Post table and User List
var getAddPost = function(req, res) {
	res.render('addPostPage.ejs', {});
};

//TODO Need to implement to deletePost to delete from Post table and User List
var deletePost = function(req, res) {
	var id = req.body.deleteBtn;
	var username = req.session.secret;
	
	post_db.delete_post(username, id, function(err){
		if(err || username == undefined) {
			var errorMessage = "Sorry, looks like we ran into an error deleting your post.";
			//console.log("error in deletePost: " + err);
			//not sure where to redirect too....
			res.render('mainpage.ejs', {'error': errorMessage});
		} else {
			res.redirect('/wall');
		}
	});
};

//TODO Need to implement to addComment to Post list 
var addComment = function(req, res) {
	var username = req.session.secret;
	var content = req.body.text;
	var id = req.body.inxid;
	
	post_db.add_comment(username, content, id, function(err){
		if (err || username == undefined) {
			var errorMessage = "Sorry, looks like we ran into an error adding your comment.";
			//not sure where to redirect too....
			res.render('mainpage.ejs', {'error': errorMessage});
		} else {
			res.redirect('/wall');
		}
	});
};
//TODO Need to implement to deleteComment from Post list
var deleteComment = function(req, res) {
	var username = req.session.secret;
	var comment = req.body.delCom;
	var id = req.body.id;
	console.log(id);
	
	post_db.delete_comment(username, comment, id, function(err){
		if (err || username == undefined) {
			var errorMessage = "Sorry, looks like we ran into an error deleting your comment.";
			//not sure where to redirect too....
			res.render('mainpage.ejs', {'error': errorMessage});
		} else {
			res.redirect('/wall');
		}
	});
};

var routes = { 
    get_wall: getWall,
    add_post: addPost,
    delete_post: deletePost,
    add_comment: addComment,
    delete_comment: deleteComment,
    get_add_post: getAddPost,
};
  
module.exports = routes;