var AWS = require('aws-sdk');
AWS.config.update({region:'us-east-1'});
var db = new AWS.DynamoDB();
var crypto = require('crypto');

/////////////////////////////////////////
/////////POST FUNCTIONS//////////////
/////////////////////////////////////////

var getWall = function(searchName, callback) {
    console.log('Looking for: ' + searchName + '\'s wall'); 
  
     //Create parameters to search table for username
    var params = {
        ExpressionAttributeValues: {
            ':u': {S: searchName}
        },
        KeyConditionExpression: 'username = :u',
        TableName: "users"
    };
    //Create a list of post_ids fron the user to look for
    let post_ids = [];
    //Query the table and return data if found
    db.query(params, function(err, data) {
        if (err || !searchName) {
            //log error if it occurs
            console.log(err);
            callback(err, []);
        } else {
            //For each post in the user table add it tot he post_ids list
            //console.log((data.Items[0].wall.NS));
            data.Items[0].wall.NS.forEach(function(post) {
                let post_id = post;
                //console.log(post_id);
                post_ids.push({'inxid': {'N': post_id}});
            });
  
            //Create parameters for batchGetItem
            //https://docs.aws.amazon.com/AWSJavaScriptSDK/latest/AWS/DynamoDB.html#batchGetItem-property
            //https://stackoverflow.com/questions/53129094/dynamodb-get-all-items-by-an-array-of-ids 
            var postParams = {RequestItems: {}};
            postParams.RequestItems['posts'] = {
                Keys: post_ids,
                //define fields
                ProjectionExpression: 'inxid, content, creator_username, comments'
            };
        
            //Query table to get the posts from post table
            db.batchGetItem(postParams, function (err, data) {
                if (err) {
                    //log error if it occurs
                    console.log(err);
                    callback(err, []);
                } else {
                    //Return data if found
                    for (x in data.Responses.post) {
                        console.log("HERE IS POST ARR: " + data.Responses.post[x].inxid.N);
                    }
                    callback(err, data.Responses.posts);
                }
            });
        }
    });
}  
  
//TODO implement functions 
var addPost = function(username, content, callback) {
    console.log("adding post from " + username);
    //Create params to get count from table
    var params1 = {
        Key: {'inxid': {N: "0"}},
        TableName: "posts",
    };
    
    //get count to get indix value
    db.getItem(params1, function(err, data) {
        //if error getting count value, callbck(err)
        if (err || data.Item == null) {
            console.log("Error getting count value in table, getItem: " + err);	
            callback(err)
        //else, add post to table using count value + 1
        } else {
            var count = parseInt(data.Item.countVal.N) + 1;
            var countString = count.toString();
            var params = {
                Item: {
                    'creator_username': {S: username},
                    'content': {S: content},
                    'comments': {L: [{L: []}]},
                    'inxid': {N: countString} ,
                },
                TableName: "posts",
            };
             //Add post to the table, if successful update count row, if not successful callback error
            db.putItem(params, function(err, data) {
                //if error putting post into table, callback(err)
                if (err) {
                    //log error if it occurs
                    console.log("Error adding post to table in putItem: " + err);
                    callback(err);
                //else, update count row value
                } else {
                    var params2 = {
                        Item: {
                            'inxid': {N: "0"} ,
                            "countVal": {N: countString}
                        },
                        TableName: "posts",
                    };
                    db.putItem(params2, function(err, data){
                        //if error callback(err)
                        if (err) {
                            console.log("Error updating count value in putItem: " + err);
                            callback(err);
                        //else, add inxid to user wall list
                        } else {
                            var params3 = {
                                TableName: "users", 
                                Key: {"username": {'S':username}}, 
                            }
                            db.getItem(params3, function(err, data){
                                if (err || data == undefined) {
                                    console.log("Error getting wall value in getItem users: " + err);
                                    callback(err);
                                } else {
                                    var wallL = (data.Item.wall.NS);
                                    var newList = [];
                                    wallL.forEach(function(num){
                                        newList.push(num);
                                    });
                                    newList.push(countString);
                                    var params4 = {
                                        TableName: "users", 
                                        Item: {
                                            "username": {'S': username}, 
                                            "affiliation": data.Item.affiliation, 
                                            "birthday": data.Item.birthday, 
                                            "email_address": data.Item.email_address, 
                                            "first_name": data.Item.first_name, 
                                            "friends": data.Item.friends, 
                                            "last_name": data.Item.last_name, 
                                            "news_interests": data.Item.news_interests, 
                                            "password": data.Item.password, 
                                            "wall": {'NS': newList},
                                            "chat_invites": data.Item.chat_invites, 
                                            "room_id": data.Item.room_id,
                                            'userStatus': data.Item.userStatus,
                                        }
                                    }
                                    db.putItem(params4, function(err, data){
                                        if (err) {
                                            console.log("Error updating wall value in putItem users: " + err);
                                            callback(err);
                                        } else {
                                            console.log("Successfully added post");
                                            callback(err);
                                        }
                                    });
                                }
                            });
                        }
                    });
                }
            });
        }
    });
}
  
var deletePost = function(username, id, callback) {
    var params = {
        Key: {'inxid': {N: id}},
        TableName: "posts",
    };
    //delete item from post table
    db.deleteItem(params, function(err){
        //if error deleting console log, callback err
        if (err) {
            console.log("Error deleting post from post table: " + err);
            callback(err);
        //else, remove post from user wall
        } else {
            var params3 = {
                TableName: "users", 
                Key: {"username": {'S':username}}, 
            }
            db.getItem(params3, function(err, data){
                if (err || data == undefined) {
                    console.log("Error getting wall value in getItem users deletion: " + err);
                    callback(err);
                } else {
                    //get wall lsit
                    var wallL = (data.Item.wall.NS)
                    var newList = []
                    //find inxid and remove from list
                    wallL.forEach(function(num){
                        if (num != id) {
                            newList.push(num);
                        }
                    })
                    var params4 = {
                        TableName: "users", 
                        Item: {
                            "username": {'S': username}, 
                            "affiliation": data.Item.affiliation, 
                            "birthday": data.Item.birthday, 
                            "email_address": data.Item.email_address, 
                            "first_name": data.Item.first_name, 
                            "friends": data.Item.friends, 
                            "last_name": data.Item.last_name, 
                            "news_interests": data.Item.news_interests, 
                            "password": data.Item.password, 
                            "wall": {'NS': newList},
                            "chat_invites": data.Item.chat_invites, 
                            "room_id": data.Item.room_id,
                            'userStatus': data.Item.userStatus,
                        }
                    }
                    db.putItem(params4, function(err, data){
                        if (err) {
                            console.log("Error deleting wall value in putItem users: " + err);
                            callback(err);
                        } else {
                            console.log("Successfully deleted post");
                            callback(err);
                        }
                    });
                }
            });
        }
    });
}
  var addComment = function(username, content, id, callback) {
      var params = {
            Key: {'inxid': {N: id}},
            TableName: "posts",
      };
      //get post from table, in order to change its contents
      db.getItem(params, function(err, data){
          //if error getting post, callback(err)
          if(err) {
              console.log("Error adding comment  in getItem posts: " + err);
              callback(err);
          //else, overwrite with new comments added
          } else {
              console.log(data.Item.comments.L);
              var commentL = data.Item.comments.L
              var stringSet = {"L": [{S: username}, {S: content}]};
              console.log("New String Set: " + stringSet.L[0] + ", " + stringSet.L[1]);
              
              var newList = []
              commentL.forEach(function(set){
                      console.log(set);
                      newList.push(set);
              })
              newList.push(stringSet);
              console.log(newList);
              var params1 = {
                  TableName: "posts",
                  Item: {
                      "inxid": {N: id},
                      "creator_username": data.Item.creator_username, 
                      "content": data.Item.content,
                      "comments": {L: newList}
                  }
              }
              db.putItem(params1, function(err){
                  if(err) {
                      console.log("Error adding comment in putItem posts: " + err);
                      callback(err);
                  } else {
                      callback(err);
                  }
              });
          }
      });
      
  }

var deleteComment = function(username, comment, id, callback) {
    var params = {
        Key: {'inxid': {N: id}},
        TableName: "posts",
    };
    //get post from table, in order to change its contents
    db.getItem(params, function(err, data){
        //if error getting post, callback(err)
        if(err) {
            console.log("Error deleting comment  in getItem posts: " + err);
            callback(err);
        //else, overwrite with new comments added
        } else {
            console.log(data.Item.comments.L);
            var commentL = data.Item.comments.L
            var stringSet = {"L": [{S: username}, {S: comment}]};
            console.log("New String Set: " + stringSet.L[0] + ", " + stringSet.L[1]);
            
            var newList = []
            commentL.forEach(function(set){
                if (set.L[0].S != username && set.L[1].S != comment) {
                    newList.push(set);
                }
            });
            console.log(newList);
            var params1 = {
                TableName: "posts",
                Item: {
                    "inxid": {N: id},
                    "creator_username": data.Item.creator_username, 
                    "content": data.Item.content,
                    "comments": {L: newList}
                }
            }
            db.putItem(params1, function(err){
                if(err) {
                    console.log("Error deleting comment in putItem posts: " + err);
                    callback(err);
                } else {
                    callback(err);
                }
            });
        }
    });
}
  

var database = { 
    get_wall: getWall,
    add_post: addPost,
    delete_post: deletePost,
    add_comment: addComment,
    delete_comment: deleteComment,
};
  
module.exports = database;